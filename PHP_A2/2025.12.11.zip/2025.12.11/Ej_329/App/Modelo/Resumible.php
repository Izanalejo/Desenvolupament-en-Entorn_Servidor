<?php

namespace App\Modelo;

interface Resumible
{
    public function muestraResumen(): void;
}